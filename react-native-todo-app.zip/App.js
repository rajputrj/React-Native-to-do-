
import React,{ useState }  from 'react';
import {
  StyleSheet,
  View,
  FlatList,
  Button
} from 'react-native';
import GoalInput from './components/GoalInput';

import GoalListing from './components/GoalListing'


const App = () => {
  const [isModalVisisble,setIsModalVisisble] =useState(false);  
  const [goalList,setGoalList] =useState([]);
  const closeModal = () => {
    setIsModalVisisble(false)
  }

  const addGoalHandler =  (goalInput)=>{
    if(goalInput ==''){return}
    setGoalList((preState)=>[...preState,{text:goalInput,id:Math.random().toString()}])
  closeModal();
  }

  const goalDeleteHandler =  (id)=>{
    setGoalList (preState=>{
      return preState.filter((goal)=>goal.id !==id)
    })
  }

 
  return (
      
      <View style={styles.appContainer}>
        <View>
          <Button title='Add Goal' onPress={()=>{
            setIsModalVisisble(true)
          }} />
        </View>
        <GoalInput closeModal={closeModal} setIsModalVisible={isModalVisisble} addGoalHandler={addGoalHandler} />
        <View style={styles.goalContainer}>
      
        <FlatList
          data={goalList}
          renderItem={(itemData)=>{
              return <GoalListing text={itemData.item.text} id={itemData.item.id} deletePressHandler={goalDeleteHandler}/>
          }}
          keyExtractor={(item,index)=>{
            return item.id;
          }}
        /></View>
      </View>
  );
};

const styles = StyleSheet.create({
  appContainer:{ 
    flex:1,
    paddingTop:20,
    paddingHorizontal:16,
    backgroundColor:'#1e085a'
  },
  goalContainer:{
    flex:6,
  },
});

export default App;
