
import React,{ useState }  from 'react';
import {
  StyleSheet,
  TextInput, 
  View,
  Button,
  Text,
  ScrollView,
  FlatList,
  Modal,
  Image
} from 'react-native';

const GoalInput = (props) => {
  const [goalInput,setGoalInput] = useState('');

  const onChangeGoalInput =(text)=>{
    setGoalInput(text)
    

  }
  const addGoal =  ()=>{
    props.addGoalHandler(goalInput)
    setGoalInput('');
  }

  // <Modal>
  //     <View style={styles.inputContainer}>
  //     <TextInput placeholder='Your Course Goal' value={goalInput} onChangeText={onChangeGoalInput} style={styles.textInput}  /><Button color='#f194ff' title='Add Goal' onPress={addGoal} />
  //     </View>
  //     </Modal>

    return (<Modal visible={props.setIsModalVisible} animationType="slide">
        <View style={styles.inputContainer}>
          <Image source={require('../assets/goal.png')} style={{width:100,height:100,margin:20}} />
        <TextInput placeholder='Your Course Goal' value={goalInput} onChangeText={onChangeGoalInput} style={styles.textInput}  />
        
          <View style={styles.buttonContainer}>
            <View  style={styles.button}>
          <Button color='#5e0acc' title='Add Goal' onPress={addGoal} />
          </View><View  style={styles.button}>
          <Button style={styles.button} color='#f31282'  title='Cancel' onPress={props.closeModal} />
          </View>

          </View></View>
        </Modal>    )
}

export default GoalInput;


const styles = StyleSheet.create({
  
  inputContainer:{
    flex:1,
    padding:20,
    flexDirection:'column',
    justifyContent:'center',
    alignItems:'center',
    backgroundColor:'#311b6b',
    color:'white'
  },
  textInput:{
    padding:10,
    width:'100%',
    borderWidth:3,
    color:'#120438',
    borderRadius:6,
    borderColor:'#e4d0ff',
    backgroundColor:'#e4d0ff',


  },
  buttonContainer:{
    flexDirection:'row',
    marginTop:10,
  },
  button:{
    width:100,
    marginHorizontal:10
  }

})