
import React  from 'react';

import {StyleSheet,View,Text,Pressable} from 'react-native';


const GoalListing = (props) => {

    return (
      <><Pressable onPress={props.deletePressHandler.bind(this,props.id)}>
        <View style={styles.goalTextContainer}><Text>{props.text}</Text></View>
        </Pressable></>
    )
}

export default GoalListing;


const styles = StyleSheet.create({
    
  goalTextContainer:{
    padding:10,
    backgroundColor:'#f194ff',
    marginVertical:8,
    borderRadius:5,
  }
})